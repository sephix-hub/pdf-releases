# PDF — note pour le service informatique

**PDF** est un lecteur / éditeur PDF portable écrit par Noé SUIVENG (bureau d'études) pour son usage
professionnel. © 2026 Noé SUIVENG, tous droits réservés.

## Ce que fait le programme
- Deux fichiers, dans le même dossier : `PDF.exe` (application) et `pdfium.dll` (moteur de rendu PDF
  open source de Google, licence BSD, version chromium/8125). Aucun service, aucun pilote.
- Mise à jour : l'application télécharge, après accord de l'utilisateur, le programme d'installation
  de la nouvelle version depuis github.com/sephix-hub/pdf-releases (contrôle de taille et
  d'empreinte SHA-256), et le lance ; l'utilisateur confirme l'installation.
- S'exécute avec les droits de l'utilisateur (manifeste `asInvoker`). Aucune élévation demandée.
- Écrit uniquement ses réglages dans `%APPDATA%\PlanPDF\settings.json`, et des fichiers temporaires
  dans `%TEMP%` (aperçus, comparaisons). Aucun autre emplacement.
- Registre : seulement si l'utilisateur clique « Ajouter PDF à Ouvrir avec » (clés sous
  `HKCU\Software\Classes`, aucune clé HKLM).
- Communication entre ses propres fenêtres : tube nommé local `\\.\pipe\PDF-NS-<utilisateur>`,
  clients distants refusés. Aucun port réseau ouvert.
- Instantanés de très grands plans : l'exe peut lancer des copies de lui-même en arrière-plan
  (`PDF.exe --rendu-bande …`) pour calculer l'image plus vite, puis elles se terminent.
- Réseau : une requête HTTPS par jour au plus vers `api.github.com` pour vérifier les mises à jour
  (désactivable dans Préférences). Téléchargement depuis `github.com/sephix-hub/pdf-releases`
  seulement après un clic de l'utilisateur, avec contrôle de taille et d'empreinte SHA-256.

## Pour l'autoriser
Ajouter une exception pour le **dossier** où PDF est installé (par défaut
`%LOCALAPPDATA%\Programs\PDF`) ou pour le dossier portable : ainsi les mises à jour suivantes
restent couvertes sans nouvelle intervention. Les empreintes SHA-256 de chaque fichier sont
publiées avec chaque version sur https://github.com/sephix-hub/pdf-releases
