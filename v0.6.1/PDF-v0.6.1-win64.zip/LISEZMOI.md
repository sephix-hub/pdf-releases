# PDF v0.6.1

Lecteur et éditeur PDF portable pour Windows 10/11 (64 bits), pensé pour un bureau d'études.
Un seul fichier `PDF.exe`, sans installation ni droits administrateur.

© 2026 Noé SUIVENG. Tous droits réservés. Logiciel propriétaire : voir *Aide → À propos*.

## Installation

1. Avant d'extraire le zip : clic droit dessus → *Propriétés* → coche **Débloquer** → *OK*.
2. Copie **les deux fichiers** `PDF.exe` et `pdfium.dll` dans un dossier à toi
   (par exemple `C:\Users\<toi>\Outils\PDF\`) et lance `PDF.exe`. Ils doivent rester ensemble.
3. Pour en faire le lecteur PDF par défaut : **Fichier → Ouvrir mes PDF avec ce logiciel**, puis
   choisis « PDF » pour `.pdf` dans la fenêtre des applis par défaut.

Réglages : `%APPDATA%\PlanPDF\settings.json`. Rien d'autre n'est écrit sur le PC.

Mises à jour : PDF vérifie une fois par jour s'il existe une nouvelle version sur
https://github.com/sephix-hub/pdf-releases et propose de l'installer (un clic, sans droits admin).
On peut couper la vérification dans *Préférences*, et vérifier à la main dans le menu *Fichier*.

## Prise en main

- **Écran d'accueil** sans document : grosses tuiles *Ouvrir*, *Fusionner*, *Images en PDF*, et les fichiers récents.
- **Ruban** en haut, comme Word : onglets *Accueil, Commenter, Pages, Modifier, Outils, Affichage*.
  Chaque bouton a une grande icône, son nom en dessous et une infobulle qui explique quoi faire.
- **Mode simple / Mode complet** (en haut à droite) : le mode simple n'affiche que l'essentiel.
- Quand un outil est actif, un bandeau bleu dit quoi faire. **Échap** pour arrêter.
- Menu bleu **Fichier** : ouvrir, enregistrer, imprimer, exporter, préférences.
- Barre rapide (Ouvrir, Enregistrer, Imprimer, Annuler, Rétablir) personnalisable dans Préférences.

## v0.6.1

- Retour de **Fichier → Ouvrir mes PDF avec ce logiciel** (disparu avec le ruban en v0.4).

## Nouveautés v0.6

**Démarrage plus « propre » pour les PC d'entreprise**
- `pdfium.dll` est livrée à côté de l'exe (plus rien n'est extrait dans AppData).
- Une seule fenêtre : les fichiers ouverts ensuite arrivent en onglet par un canal Windows local (tube nommé), plus de port réseau.
- Plus de relance automatique : en cas de souci d'affichage, le *mode graphique de secours* s'active pour le lancement suivant.
- Manifeste Windows standard (s'exécute sans droits admin), nouveau logo rouge.

**Mises à jour depuis GitHub** : bandeau « Nouvelle version disponible — Mettre à jour » ; rien n'est installé sans clic.

**Compter les blocs AutoCAD** (Outils → Compter les blocs)
- PDF lit les calques du plan et regroupe les traits en blocs. Coche un calque (ex. EESN-CFO-PRISE DE COURANT)
  ou clique sur un symbole avec *Choisir sur le plan* : chaque bloc est encadré et compté, rangé par type
  (Type 1, Type 2… avec une vignette). Un bloc triple compte pour un bloc triple.
- La légende et le cartouche sont exclus ; *Limiter à une zone* pour compter une pièce ou un niveau.
- Re-clic sur un bloc avec *Choisir sur le plan* pour le retirer (ou le remettre).
- *Exporter vers Excel* : plan, calque, type, taille, quantité, pour tous les plans ouverts.

**Calques** (Affichage → Calques) : afficher / masquer les calques, recherche par nom,
« Afficher seulement ceux-là ». L'impression, les instantanés et les exports suivent. Le fichier n'est pas modifié.

**Mesures**
- *Accrochage* aux extrémités (carré), milieux (triangle) et croisements (croix) des traits. Alt = mesure libre.
- *Détecter l'échelle* : lit « Échelle 1/50 » sur la page et propose de l'appliquer (jamais automatique).

**Comparer deux indices** : si le nouvel indice est décalé, il est recalé automatiquement avant la comparaison,
avec une tolérance d'un pixel (moins de fausses différences).

## Nouveautés v0.5

**Comparer deux indices d'un plan** (Outils → Comparer deux indices, ou menu Fichier)
- Choisis l'ancien et le nouvel indice (onglets ouverts ou fichiers). Le résultat s'ouvre dans un nouvel onglet :
  **rouge** = supprimé, **vert** = ajouté, **gris** = inchangé. Les zones modifiées sont encadrées en orange
  et listées dans la *Liste des annotations*. Enregistre-le avec *Enregistrer sous* pour le garder.
- Les pages sont comparées dans l'ordre ; les deux plans doivent avoir le même cadrage.

**Mesures avancées** (onglet Outils)
- **Longueur** : tracé en plusieurs segments (gaine, réseau, cloison), double-clic pour finir.
- **Compter** : clique sur chaque symbole ; re-clic sur un repère pour l'enlever. Plusieurs catégories
  (nom et couleur), totaux en direct dans le panneau **Mesures** à droite.
- **Résultats** : totaux des longueurs et surfaces, **export Excel** (fichier .csv qui s'ouvre dans Excel),
  et **Enregistrer dans le PDF** pour dessiner les cotes, surfaces et repères dans le plan (annulable par Ctrl+Z).

**Compresser le PDF** (Outils → Compresser, ou menu Fichier)
- Trois niveaux : mail (150 ppp, conseillé), écran (100 ppp), impression (220 ppp).
  Seules les images sont allégées ; texte et traits restent nets. Un nouveau fichier est créé, l'original n'est pas touché.

**Liste des annotations** (Commenter → Liste des annotations) — cachée par défaut
- Toutes les annotations du document : type, page, auteur, date, commentaire. Clic = aller à l'annotation.
- Filtre par auteur, recherche dans les commentaires, suppression, export Excel.

## Nouveautés v0.4

**Instantanés plus rapides**
- 150 ppp par défaut. Rendu direct, découpage en bandes calculées en parallèle sur les gros plans (1900 × 900 mm…),
  copie native dans le presse-papier Windows (plus d'encodage PNG).

**Copier pour Word**
- Un bouton : toutes les pages (ou une plage) partent dans le presse-papier, une image par page, une page Word par page PDF, en A4.
  Ouvre Word et fais Ctrl+V. Qualité 150, 200 ou 300 ppp.
- Format **Image PNG** (léger) ou **Bitmap** (qualité maximale, comme « Collage spécial → Bitmap », plus lourd).
  Pour une seule page en Bitmap, « Collage spécial → Bitmap » est aussi proposé dans Word.
- Pour que Word ne réduise pas les images à l'enregistrement : *Fichier → Options → Options avancées →
  Taille et qualité de l'image* → coche **Ne pas compresser les images dans le fichier** et choisis **Haute fidélité**.

**Modifier le PDF**
- **Corriger le texte** : clique sur une ligne (ou encadre un passage), corrige, *Remplacer*. L'ancien texte est supprimé du fichier.
- **Signature** : signe une fois à la souris (ou choisis une image scannée), elle est mémorisée, puis clique pour la poser.
- **Tampons** : BON POUR EXÉCUTION, VALIDÉ, VU, POUR INFORMATION, PROVISOIRE, À REPRENDRE, REFUSÉ, ANNULÉ,
  ou ton tampon perso, avec date et nom en option.
- **Image / logo** à poser sur la page.
- **Filigrane** (COPIE, CONFIDENTIEL…) et **numéros de page / en-têtes / pieds** (`{n}`, `{total}`, `{date}`, `{fichier}`) sur toutes les pages ou une plage.
- **Masquer une zone** (caviardage) : le texte dessous est supprimé du fichier, puis recouvert de noir.
  Une ligne de texte touchée est supprimée en entier, par sécurité.
- **Recadrer** une page ou toutes les pages.
- **Figer** les annotations dans la page.
- Annotations : avec la Main, clique dessus pour les **déplacer**, les **redimensionner** (poignées),
  changer couleur et épaisseur ou les supprimer via la petite barre qui apparaît.

**Pages et fichiers**
- **Organiser les pages** : grille de miniatures, glisser-déposer pour réordonner, Ctrl/Maj+clic, clic droit = actions.
- **Fusionner** plusieurs PDF (onglets ouverts ou fichiers), **Découper** (toutes les N pages, par plages, une page par fichier),
  **Pages en images** (PNG/JPEG), **Images en PDF**, insérer des images comme pages.

## Fonctions déjà présentes

- Onglets, glisser un onglet hors de la fenêtre = nouvelle fenêtre (deux écrans).
- Grands plans par tuiles, zoom jusqu'à 6400 %, défilement continu ou page par page.
- Recherche, liens, signets, miniatures, mesures à l'échelle avec étalonnage.
- Impression bureau d'études : format automatique par page (A4/A3 mélangés), traceur au format exact,
  noir pur, recto verso, profils.

## Limites connues

- Pas encore : formulaires remplissables, OCR, comparaison de plans.
- Corriger le texte réécrit la ligne en Helvetica : la police d'origine n'est pas conservée.

## Compiler

```
sudo apt install mingw-w64
rustup target add x86_64-pc-windows-gnu
cargo build --release --target x86_64-pc-windows-gnu
```

`vendor/pdfium-render` : pdfium-render 0.9.5 avec handles PDFium exposés. PDFium chromium/8125.
